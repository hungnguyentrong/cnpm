package Backend.service;

public interface VehicleService {

}
