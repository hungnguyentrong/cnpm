package Backend.repository;

public class VehicleRepository {

}
